# This is an example test for Sauce Labs and Appium.
# It expects SAUCE_USERNAME and SAUCE_ACCESS_KEY to be set in your environment.
#
# Before this test will work, you may need to do:
# 
# gem install rspec selenium-webdriver rest-client
#
# Run with:
#
# rspec sauce_example.rb
require 'rspec'
require 'selenium-webdriver'
require 'json'
require 'rest_client'

APP_PATH = 'http://appium.s3.amazonaws.com/TestApp6.0.app.zip'
SAUCE_USERNAME = ENV['SAUCE_USERNAME']
SAUCE_ACCESS_KEY = ENV['SAUCE_ACCESS_KEY']

# This is the test itself
describe "Computation" do
  before(:each) do
    @driver = Selenium::WebDriver.for(
      :remote, 
      :desired_capabilities => desired_caps, 
      :url => server_url
    )
  end

  after(:each) do
    # Get the success by checking for assertion exceptions,
    # and log them against the job, which is exposed by the session_id
    job_id = @driver.send(:bridge).session_id
    update_job_success(job_id, example.exception.nil?)
    @driver.quit
  end

  it "should add two numbers" do
    values = [rand(10), rand(10)]
    expected_sum = values.reduce(&:+)
    elements = @driver.find_elements(:tag_name, 'textField')

    elements.each_with_index do |element, index|
      element.send_keys values[index]
    end

    @driver.find_elements(:tag_name, 'button')[0].click
    @driver.find_elements(:tag_name, 'staticText')[0].text.should eq expected_sum.to_s
  end
end

def desired_caps
  {
      'browserName' => '',
      'platform' => 'Mac 10.8',
      'version' => '6.1',
      'device' => 'iPhone Simulator',
      'app' => APP_PATH,
      'name' => 'Ruby Example for Appium',
  }
end

def auth_details
  un = SAUCE_USERNAME
  pw = SAUCE_ACCESS_KEY
  
  unless un && pw
    STDERR.puts <<-EOF
      Your SAUCE_USERNAME or SAUCE_ACCESS_KEY environment variables 
      are empty or missing.
      
      You need to set these values to your Sauce Labs username and access
      key, respectively.

      If you don't have a Sauce Labs account, you can get one for free at
      http://www.saucelabs.com/signup
    EOF

    exit
  end

  return "#{un}:#{pw}"
end

def server_url
  "http://#{auth_details}@ondemand.saucelabs.com:80/wd/hub"
end

def rest_jobs_url
  "https://#{auth_details}@saucelabs.com/rest/v1/#{SAUCE_USERNAME}/jobs"
end

# Because WebDriver doesn't have the concept of test failure, use the Sauce
# Labs REST API to record job success or failure
def update_job_success(job_id, success)
    RestClient.put "#{rest_jobs_url}/#{job_id}", {"passed" => success}.to_json, :content_type => :json
end

"use strict";

describe('safari - webview -', function () {
  require('../../common/webview-base')('safari');
});

"use strict";

describe('iwebview @skip-ios-all', function () {
  var app = 'iwebview';
  require('../common/webview-base')(app);
});

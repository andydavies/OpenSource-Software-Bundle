"use strict";

var getAppPath = require('../../../helpers/app').getAppPath;

module.exports = {
  app: getAppPath('WebViewApp')
};

package com.noshufou.android.su;

public interface FragmentWithLog {
    
    public void clearLog();

}
